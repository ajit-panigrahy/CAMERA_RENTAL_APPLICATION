package jfsd.cra;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class RemoveCamera implements RemoveCameraIn {
	private ArrayList<Camera> cameraList = new CameraList().getCameraList();
	private Map<Integer, Camera> cameraMap = initializeCameraMap();
	private Scanner sc = new Scanner(System.in);

	private Map<Integer, Camera> initializeCameraMap() {
		Map<Integer, Camera> map = new HashMap<>();
		for (Camera cam : cameraList) {
			map.put(cam.getId(), cam);
		}
		return map;
	}

	@Override
	public ArrayList<Camera> setNewCameraList(int cameraId) {
		try {
			String password = Users.getPassword();
			System.out.println("Enter Your Password : ");
			String pass = sc.nextLine();

			if (password.equals(pass)) {
				Camera removedCamera = cameraMap.remove(cameraId);

				if (removedCamera != null) {
					cameraList.remove(removedCamera);
					System.out.println("Camera With ID " + cameraId + " Removed Successfully");
				} else {
					System.out.println("Camera with ID " + cameraId + " not found.");
				}
			} else {
				System.out.println("Incorrect Password. Camera Not Removed.");
				new MyCamera().displayMyCameraMenu();
			}
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		} finally {
			if (sc != null) {
				sc.close();
			}
		}

		return cameraList;
	}
}
