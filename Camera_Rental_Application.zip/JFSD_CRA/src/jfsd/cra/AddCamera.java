package jfsd.cra;

import java.util.ArrayList;
import java.util.Scanner;

public class AddCamera implements AddCameraIn {
	private ArrayList<Camera> cameraList = new CameraList().getCameraList();
	Scanner sc = new Scanner(System.in);

	@Override
	public ArrayList<Camera> setNewCameraList() {
		try {
			String password = Users.getPassword();
			System.out.println("Enter Camera Brand : ");
			String brand = sc.next();
			System.out.println("Enter Camera Model : ");
			String model = sc.next();
			System.out.println("Enter Camera Price Per Day : ");
			double price = sc.nextDouble();
			sc.nextLine();
			System.out.println("Enter Your Password : ");
			String pass = sc.nextLine();

			if (password.equals(pass)) {
				int id = cameraList.size() + 1;
				cameraList.add(new Camera(id, brand, model, price, true));
				System.out.println("Camera Added Successfully");
			} else {
				System.out.println("Incorrect Password. Camera Not Added.");
				new MyCamera().displayMyCameraMenu();
			}
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		}
		return cameraList;
	}
}
