package jfsd.cra;

import java.util.ArrayList;

public interface RemoveCameraIn {

	ArrayList<Camera> setNewCameraList(int cameraId);

}
