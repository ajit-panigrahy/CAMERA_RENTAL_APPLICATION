package jfsd.cra;

import java.util.ArrayList;

public interface AddCameraIn {
	ArrayList<Camera> setNewCameraList();
}
