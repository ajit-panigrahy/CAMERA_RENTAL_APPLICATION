package jfsd.cra;

public interface MainMenu {

	void displayMainMenu();

}
