package jfsd.cra;

import java.util.ArrayList;

public class CameraList {

	private ArrayList<Camera> cameraList = new ArrayList<>();

	public CameraList() {
		// Constructor: Initialize the cameraList and add cameras
		cameraList.add(new Camera(1, "NIKON", "NK24-001", 100, true));
		cameraList.add(new Camera(2, "GOPRO", "GP24-001", 2300, true));
		cameraList.add(new Camera(3, "CANON", "CN24-001", 400, true));
		cameraList.add(new Camera(4, "NIKON", "NK24-001", 700, false));
		cameraList.add(new Camera(5, "SONY", "SY24-001", 300, true));
		cameraList.add(new Camera(6, "NIKON", "NK24-002", 500, true));
		cameraList.add(new Camera(7, "SONY", "SY24-002", 800, false));
		cameraList.add(new Camera(8, "PANASONIC", "PS24-001", 1100, false));
		cameraList.add(new Camera(9, "CANON", "CN24-002", 600, true));
		cameraList.add(new Camera(10, "SONY", "SY24-003", 1100, false));
		cameraList.add(new Camera(11, "NIKON", "NK24-003", 100, true));
		cameraList.add(new Camera(12, "GOPRO", "GP24-002", 2300, true));
		cameraList.add(new Camera(13, "CANON", "CN24-003", 400, true));
		cameraList.add(new Camera(14, "NIKON", "NK24-004", 700, false));
		cameraList.add(new Camera(15, "SONY", "SY24-004", 300, true));
		cameraList.add(new Camera(16, "NIKON", "NK24-005", 500, true));
		cameraList.add(new Camera(17, "SONY", "SY24-005", 800, false));
		cameraList.add(new Camera(18, "PANASONIC", "PS24-002", 1100, false));
		cameraList.add(new Camera(19, "CANON", "CN24-004", 600, true));
		cameraList.add(new Camera(20, "SONY", "SY24-005", 1100, false));
	}

	public ArrayList<Camera> getCameraList() {
		return cameraList;
	}

	public void setCameraList(ArrayList<Camera> cameraList) {
		this.cameraList = cameraList;
	}
}
