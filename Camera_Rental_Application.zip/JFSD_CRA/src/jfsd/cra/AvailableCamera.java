package jfsd.cra;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AvailableCamera {

	private ArrayList<Camera> cameraList = new CameraList().getCameraList();
	private Map<Integer, Camera> availableCameraMap = new LinkedHashMap<>();

	public AvailableCamera() {
		try {
			initializeAvailableCameraMap();
		} catch (Exception e) {
			System.out.println("An error occurred during initialization: " + e.getMessage());
			e.printStackTrace();
		}
	}

	private void initializeAvailableCameraMap() {
		for (Camera cam : cameraList) {
			if (cam.isAvailable()) {
				availableCameraMap.put(cam.getId(),
						new Camera(cam.getId(), cam.getBrand(), cam.getModel(), cam.getPricePerDay(), true));
			}
		}
	}

	public List<Camera> cameraAvailable() {
		return new ArrayList<>(availableCameraMap.values());
	}

	public void rentCamera(int camID) {
		try {
			new Users();
			double walletBalance = Users.getWalletBalance();
			Camera cam = availableCameraMap.get(camID);

			if (cam != null) {
				double cameraPrice = cam.getPricePerDay();

				if (walletBalance > cameraPrice) {
					System.out.println("YOUR TRANSACTION FOR CAMERA ");
					System.out.println(
							cam.getBrand() + " " + cam.getModel() + " with rent " + cameraPrice + " has completed.");
					System.out.println("YOUR WALLET BALANCE IS : " + (walletBalance - cameraPrice));
				} else {
					System.out.println("Insufficient funds to rent the camera.");
				}
			} else {
				System.out.println("Camera Doesn't Exist or is not available");
			}
		} catch (Exception e) {
			System.out.println("An error occurred during camera rental: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
