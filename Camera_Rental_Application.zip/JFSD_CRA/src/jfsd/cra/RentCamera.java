package jfsd.cra;

import java.util.ArrayList;
import java.util.Scanner;

public class RentCamera {

	private Scanner sc = new Scanner(System.in);

	public void rentAvaiableCamera() {
		ArrayList<Camera> cameraList = (ArrayList<Camera>) new AvailableCamera().cameraAvailable();
		System.out.println("=============================================================================");
		System.out.printf("%-12s%-12s%-16s%-20s%s%n", "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
		System.out.println("=============================================================================");

		for (Camera camera : cameraList) {
			System.out.printf("%-12d%-12s%-16s%-20.2f%s%n", camera.getId(), camera.getBrand(), camera.getModel(),
					camera.getPricePerDay(), camera.isAvailable() ? "Available" : "Rented");
		}
		System.out.println("=============================================================================");

		System.out.println("Enter Camera ID Which You Want To Rent : ");
		int camID = sc.nextInt();
		new AvailableCamera().rentCamera(camID);
		new DisplayMainMenu().displayMainMenu();
	}

}
