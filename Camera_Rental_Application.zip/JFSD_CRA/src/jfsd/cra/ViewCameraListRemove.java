package jfsd.cra;

import java.util.ArrayList;

public class ViewCameraListRemove {
	public static void viewCameraListRemove(ArrayList<Camera> cameraListRemove) {
		try {
			System.out.println("New Camera List");
			System.out.println("=============================================================================");
			System.out.printf("%-12s%-12s%-16s%-20s%s%n", "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
			System.out.println("=============================================================================");

			for (Camera camera : cameraListRemove) {
				System.out.printf("%-12d%-12s%-16s%-20.2f%s%n", camera.getId(), camera.getBrand(), camera.getModel(),
						camera.getPricePerDay(), camera.isAvailable() ? "Available" : "Rented");
			}
			System.out.println("=============================================================================");
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
			new MyCamera().displayMyCameraMenu();
		}
	}
}
