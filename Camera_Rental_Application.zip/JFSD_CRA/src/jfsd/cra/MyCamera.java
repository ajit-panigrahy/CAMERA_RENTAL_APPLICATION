package jfsd.cra;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MyCamera {

	private Scanner scanner = new Scanner(System.in);

	public void displayMyCameraMenu() {
		try {
			do {
				System.out.println("\nOPTIONS:");
				System.out.println("1. Add Camera");
				System.out.println("2. Remove Camera");
				System.out.println("3. View All Cameras");
				System.out.println("4. Previous Menu");

				int choice = scanner.nextInt();

				if (choice >= 1 && choice <= 4) {
					switch (choice) {
					case 1:
						addCamera();
						break;
					case 2:
						removeCamera();
						break;
					case 3:
						viewCameraList();
						break;
					case 4:
						new DisplayMainMenu().displayMainMenu();
						break;
					default:
						throw new IllegalArgumentException("Unexpected value: " + choice);
					}

					break; // Exit the loop if a valid option is chosen
				} else {
					System.out.println("Invalid option. Please try again.");
				}
			} while (true);

		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Please enter a valid number.");
			scanner.nextLine(); // Consume the invalid input
			displayMyCameraMenu(); // Restart the menu
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		}
	}

	private void addCamera() {
		try {
			ArrayList<Camera> cameraListAdd = new AddCamera().setNewCameraList();
			ViewCameraListAdd.viewCameraListAdd(cameraListAdd);
		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Please enter a valid number.");
			scanner.nextLine();
			addCamera(); // Restart the add camera process
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
			displayMyCameraMenu();
		}
	}

	private void removeCamera() {
		try {
			System.out.println("Current Camera List");
			viewCameraList();
			System.out.println("Enter Camera ID You Want To Remove ");
			int cameraId = scanner.nextInt();
			ArrayList<Camera> cameraListRemove = new RemoveCamera().setNewCameraList(cameraId);
			ViewCameraListRemove.viewCameraListRemove(cameraListRemove);
		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Please enter a valid number.");
			scanner.nextLine(); // Consume the invalid input
			removeCamera(); // Restart the remove camera process
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		}
	}

	private void viewCameraList() {
		try {
			ViewAllCamera.viewCameraList();
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
			displayMyCameraMenu();
		}
	}

}
