package jfsd.cra;

import java.util.Scanner;

public class UserWallet {
	private static Scanner sc = new Scanner(System.in);
	static double userBalance = Users.getWalletBalance();

	public static void walletBalance() {
		try {
			System.out.println("YOUR CURRENT WALLET BALANCE IS : INR " + userBalance);

			do {
				System.out.println("DO YOU WANT TO ADD MORE BALANCE TO YOUR WALLET \n 1.YES 2.NO");
				int opt = sc.nextInt();

				if (opt == 1 || opt == 2) {
					switch (opt) {
					case 1:
						addBalance();
						break;
					case 2:
						System.out.println("Thank You :)");
						new DisplayMainMenu().displayMainMenu();
						break;
					}
					break;
				} else {
					System.out.println("Invalid Option. Please Try Again... ");
					break;
				}
			} while (true);

		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
		}
	}

	private static void addBalance() {
		try {
			System.out.println("ENTER AMOUNT (INR) ");
			double addBal = sc.nextDouble();
			double newBalance = userBalance + addBal;
			System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY");
			System.out.println("YOUR CURRENT BALANCE : INR " + newBalance);

		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		} finally {
			new DisplayMainMenu().displayMainMenu();
		}
	}
}
